function resultLabel = binary_KNN(inx,data,labels,k, weightedD , modeD,W0 )

%   inx Ϊ ����������ݣ�dataΪ�������ݣ�labelsΪ������ǩ
% W0
%%
    [datarow ,~] = size(data);
    [inxrow, ~] = size(inx) ;
    resultLabel = zeros(inxrow,1);
    for i=1:inxrow
        
        diff = repmat(inx(i,:),[datarow,1]) - data ;
%         diffSquare = pdist(diff,'minkowski',2);
        
        % W0 = [0.690623963413343;-2.07276522012273;-1.02031819513664;1.90698163854682;3.20141557241918;1.41538300987449;-2.81283806229049;0.459736596204493;1.25366500314865;0.0643424164887058;0.164268371517106;1.03364035795673;0.802590505543711;0.742101542321884;0.490451153342561;1.02618834826582;0.422785842170500;-0.0324501967509968];
        if(modeD == 1)
            diffSquare = sum(diff, 2);   % ��������
        elseif( modeD ==2 )                 
            diffSquare = sum(diff .^2, 2);  % ŷʽ����
        elseif( modeD ==3 )
            diffSquare = sum(diff .^3, 2) ;  % ŷʽ����
        elseif( modeD == 111 )
            diffSquare =  (diff .^2) * W0 ;  % ��Ȩŷʽ����
        elseif( modeD == 222 )    
            diffSquare_1 =  (diff .^2) * W0 ;  % ��Ȩŷʽ����exp
            a = 1;
            diffSquare = diffSquare_1 .* exp(- 0.5 *diffSquare_1 * a ) ;
        end
    
        [sortDiff , index] = sort(diffSquare,'ascend');
        Ktrue = min(k,length(sortDiff));

    %     D = zeros(len,1); %distance�ĵ���
         %distance�ĵ���
        if weightedD == 0
            % �޼�Ȩ�Ľ��
            resultLabel(i) = mode( labels( index(1:Ktrue) ) );
        elseif( weightedD == -333 )
            a = 1;    
            kD = exp(- 0.5 *diffSquare * a ) ;   
            [~,I] = max([sum( kD( labels( index(1:Ktrue) )==0 ) ), sum( kD( labels( index(1:Ktrue) )==1 ) ) ]);
            % I=1 �� NegƱ���࣬I=2��PosƱ����
            resultLabel(i) = I-1;
        else        
            kD = weightedD ./ sortDiff(1:Ktrue);
            %distance ��˹����
            kD( kD < 1 ) = 1 ;
            [~,I] = max([sum( kD( labels( index(1:Ktrue) )==0 ) ), sum( kD( labels( index(1:Ktrue) )==1 ) ) ]);
            % I=1 �� NegƱ���࣬I=2��PosƱ����
            resultLabel(i) = I-1;
        end

    end

end