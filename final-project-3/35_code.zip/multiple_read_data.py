import numpy as np
import cmath
import time
import csv
import re
from gensim.models import word2vec


raw_xLines_train = []
raw_xLines_vali = []
raw_xLines_test = []
xLines_train = []  # 从训练集提取出的有效信息，每个元素是一个list，对应每行的词集
xLines_vali = []  # 从验证集提取出的有效信息，每个元素是一个list，对应每行的词集
xLines_test = []  # 从验证集提取出的有效信息，每个元素是一个list，对应每行的词集
y_train = []  # 训练集标签
y_vali = []  # 验证集标签
y_test = []  # 验证集标签
word_vector = {}
train_word2vector = {}
vali_word2vector = {}
test_word2vector = {}

pat1 = re.compile("\s[!”#$%&’()*+,-.\'/:;<=>?@\[\]^_`{|}~]+\s")
pat2 = re.compile("\s[!”#$%&’()*+,-.\'/:;<=>?@\[\]^_`{|}~]+$")

y_raw2vector = {'LOW': np.array([1, 0, 0]), 'MID': np.array([0, 1, 0]), 'HIG': np.array([0, 0, 1])}

# 训练集
train_file = "F:\\AI\\Project\\multi-classification\\MulLabelTrain_divided.ss"
# 验证集
vali_file = "F:\\AI\\Project\\multi-classification\\MulLabelVali_divided.ss"
# 测试集
test_file = "F:\\AI\\Project\\multi-classification\\MulLabelTest.ss"

WORD_VECTOR_SIZE = 150

def get_sentence_vector(raw_xline):
    sentence_vector = np.zeros(WORD_VECTOR_SIZE)
    default_vector = np.random.randn(WORD_VECTOR_SIZE)
    word_cnt = 0
    for w in raw_xline:
        word_cnt += 1
        try:
            vec=train_word2vector[w]
            sentence_vector += vec  # word_vector.get(w, default_vector)
        except KeyError:
            sentence_vector += default_vector
    #sentence_vector = np.append(sentence_vector, np.sin(sentence_vector))
    return sentence_vector/word_cnt


# 大约15s
def train_to_x_matrix():
    global xLines_train
    for line in raw_xLines_train:
        xLines_train.append(get_sentence_vector(line))
    xLines_train = np.array(xLines_train)

# 大约15s
def test_to_x_matrix():
    global xLines_test
    for line in raw_xLines_test:
        xLines_test.append(get_sentence_vector(line))
    xLines_test = np.array(xLines_test)

# 大约15s
def vali_to_x_matrix():
    global xLines_vali
    for line in raw_xLines_vali:
        xLines_vali.append(get_sentence_vector(line))
    xLines_vali = np.array(xLines_vali)

def remove_punctuation(sentence: str):
    output = pat1.sub(" ", sentence)
    output = pat2.sub("", output)
    return output


# 大约5s
def read_vali_text():
    global y_vali
    with open(vali_file, 'r', encoding='UTF-8') as fin:
        lines = fin.readlines()
    for line in lines:
        line = line.strip()
        x_y_divided = line.split("\t\t")
        y_vali.append(y_raw2vector[x_y_divided[0]])
        x_divided = x_y_divided[1].split(" <sssss> ")  # 分成句子
        x_words = []
        for sentence in x_divided:  # 提取出单词，放在x_words里面
            #sentence = remove_punctuation(sentence)
            words = sentence.split(" ")
            x_words.extend(words)
        raw_xLines_vali.append(x_words)
    y_vali = np.array(y_vali)
    vali_to_x_matrix()

def read_train_text():
    global y_train
    global train_word2vector
    with open(train_file, 'r', encoding='UTF-8') as fin:
        lines = fin.readlines()
    for line in lines:
        line = line.strip()
        x_y_divided = line.split("\t\t")
        y_train.append(y_raw2vector[x_y_divided[0]])
        x_divided = x_y_divided[1].split(" <sssss> ")  # 分成句子
        x_words = []
        for sentence in x_divided:  # 提取出单词，放在x_words里面
            words = sentence.split(" ")
            x_words.extend(words)
        raw_xLines_train.append(x_words)
    y_train = np.array(y_train)

    # 35_gensim_word2vec
    train_word2vector = word2vec.Word2Vec(raw_xLines_train, size=WORD_VECTOR_SIZE, min_count=2)########

    train_to_x_matrix()

# 大约5s
def read_test_text():
    global y_test
    with open(test_file, 'r', encoding='UTF-8') as fin:
        lines = fin.readlines()
    for line in lines:
        line = line.strip()
        x_y_divided = line.split("\t\t")
        y_test.append(x_y_divided[0])
        x_divided = x_y_divided[1].split(" <sssss> ")  # 分成句子
        x_words = []
        for sentence in x_divided:  # 提取出单词，放在x_words里面
            words = sentence.split(" ")
            x_words.extend(words)
        raw_xLines_test.append(x_words)
    y_test = np.array(y_test)
    test_to_x_matrix()

