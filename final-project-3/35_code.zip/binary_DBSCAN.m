% -------------------------------------------------------------------------
% Function: [class,type]=DBSCAN_v1(x, MinPts ,Eps)
% Input: 
% x --------- ���ݼ� (m,n); m-objects, n-variables
% MinPts ---- �뾶�ڵ���С����
% (minimal number of objects considered as a cluster)
% Eps - �趨�İ뾶��������OPTICS��Eps������Eps=[]
% -------------------------------------------------------------------------
% Output: 
% class --- �����ظ��أ����ﲻ���ģ���Ҫ��Ϊ���б������㣩
% type ---- ����ʲô���͵ĵ�(����core: 1, �߽�border: 0, ����outlier: -1)
% -------------------------------------------------------------------------

function [class,type]=binary_DBSCAN(x, MinPts ,Eps)
x=zscore(x);%standarlize
[m,~]=size(x);

if nargin<3||isempty(Eps)
   [Eps]=epsilon(x,MinPts);
end

x=[(1:m)',x];
[m,n]=size(x);
type=zeros(1,m);
class=zeros(1,m);
no=1;
touched=zeros(m,1);

for i=1:m
    if touched(i)==0;
       ob=x(i,:);
       D=dist(ob(2:n),x(:,2:n));
       ind=find(D<=Eps);
    
       if length(ind)>1 && length(ind)<MinPts+1       
          type(i)=0;
          class(i)=0;
       end
       if length(ind)==1
          type(i)=-1;
          class(i)=-1;  
          touched(i)=1;
       end

       if length(ind)>=MinPts+1; 
          type(i)=1;
          class(ind)=ones(length(ind),1)*max(no);
          
          while ~isempty(ind)
                ob=x(ind(1),:);
                touched(ind(1))=1;
                ind(1)=[];
                D=dist(ob(2:n),x(:,2:n));
                i1=find(D<=Eps);
     
                if length(i1)>1
                   class(i1)=no;
                   if length(i1)>=MinPts+1;
                      type(ob(1))=1;
                   else
                      type(ob(1))=0;
                   end

                   for k1=1:length(i1)
                       if touched(i1(k1))==0
                          touched(i1(k1))=1;
                          ind=[ind,i1(k1)];   
                          class(i1(k1))=no;
                       end                    
                   end
                end
          end
          no=no+1; 
       end
   end
end

i1=find(class==0);
class(i1)=-1;
type(i1)=-1;

% disp(clun);

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Eps]=epsilon(x,k)

% Function: [Eps]=epsilon(x,k)
% Aim: 
% ΪDBSCAN�ҵ�һ�����ʵ�Eps
% Input: 
% x --------- ���ݼ� (m,n); m-objects, n-variables
% k -------- �뾶�ڵ���С����

[m,n]=size(x);
% �ο�OPTICS����
Eps=((prod(max(x)-min(x))*k*gamma(.5*n+1))/(m*sqrt(pi.^n))).^(1/n);
disp('EPS:');
disp(Eps);

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [D]=dist(i,x)
[m,n]=size(x);
D=sqrt(sum((((ones(m,1)*i)-x).^2)'));
if n==1
   D=abs((ones(m,1)*i-x))';
end

