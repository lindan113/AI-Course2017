import numpy as np
import cmath
import time
import csv
import re
import multiple_read_data

cnt = 0

min_vector = []
max_vector = []


def de_center_no_abs(input_matrix):
    global min_vector, max_vector
    if len(min_vector) == 0:
        min_vector = np.min(input_matrix, axis=0)
    if len(max_vector) == 0:
        max_vector = np.max(input_matrix, axis=0)
    input_matrix = (input_matrix - min_vector) / (max_vector - min_vector)
    input_matrix *= 2
    # input_matrix /= np.std(input_matrix, axis=0)
    return input_matrix - np.mean(input_matrix, axis=0)


def p_to_10(x):
    x[x.argmax()] = 1
    x[x != 1] = 0


class NeuralNetwork(object):
    def __init__(self, input_nodes, hidden_nodes, output_nodes,
                 learning_rate,
                 dropout_prob=0.5):
        # Set number of nodes in input, hidden and output layers.
        self.input_nodes = input_nodes
        self.hidden_nodes = hidden_nodes
        self.output_nodes = output_nodes
        self.dropout_prob = dropout_prob

        # Initialize weights
        # this is a MATRIX
        self.weights_input_to_hidden = 0.0001 * np.random.randn(hidden_nodes, input_nodes)
        # this is a VECTOR
        self.weights_hidden_to_output = 0.0001 * np.random.randn(output_nodes, hidden_nodes)

        # two bias
        self.bias_input_to_hidden = 0.00001 * np.random.randn(hidden_nodes)
        self.bias_hidden_to_output = 0.00001 * np.random.randn(output_nodes)

        self.best_weights_input_to_hidden = 0.0001 * np.random.randn(hidden_nodes, input_nodes)
        # this is a VECTOR
        self.best_weights_hidden_to_output = 0.0001 * np.random.randn(output_nodes, hidden_nodes)

        # two bias
        self.best_bias_input_to_hidden = 0.00001 * np.random.randn(hidden_nodes)
        self.best_bias_hidden_to_output = 0.00001 * np.random.randn(output_nodes)

        self.best_acc = 0

        self.lr = learning_rate

        # Activation function is the sigmoid/tanh function
        def deri_relu(x):
            y = x.copy()
            y[y < 0] = 0
            y[y >= 0] = 1
            return y

        self.deri_relu = deri_relu

        def relu(x):
            y = x.copy()
            y[y < 0] = 0
            return y

        self.hidden_activation_function = lambda x: np.tanh(x)
        self.output_activation_function = lambda x: np.exp(x) / (
        np.sum(np.exp(x), axis=1).reshape(-1, 1))  # lambda x: np.exp(x)/np.sum(np.exp(x)) # x is a np.array
        self.accuracy_list = []
        self.entropy_list = []
        self.vali_accuracy_list = []
        self.vali_entropy_list = []
        self.arrive_05 = False
        self.arrive_06 = False

    def train(self, inputs_matrix: np.array, targets_list: np.array,
              vali_inputs_matrix: np.array, vali_targets_list: np.array,
              batch_size: int, rounds: int):
        debug_range = range(len(targets_list))
        selected_positions = np.random.choice(debug_range, batch_size, replace=False)
        input_to_hidden_grad = np.zeros((self.hidden_nodes, self.input_nodes))
        hidden_to_output_grad = np.zeros((self.output_nodes, self.hidden_nodes))
        bias_input_to_hidden_grad = np.zeros(self.hidden_nodes)
        bias_hidden_to_output_grad = np.zeros(self.output_nodes)

        drop_mask = self.dropout_mask(self.hidden_nodes, self.dropout_prob)
        # for Xk,Yk, update weights
        for k in selected_positions:
            # ##BEGIN Forward pass ###
            # a hidden input vector
            hidden_inputs = inputs_matrix[k].dot(self.weights_input_to_hidden.T) - self.bias_input_to_hidden
            # a hidden output vector
            hidden_outputs = self.hidden_activation_function(hidden_inputs)

            # Drop out!
            hidden_outputs = self.mask_x(hidden_outputs, self.dropout_prob, drop_mask)

            # Output layer (yk_hat)
            final_inputs = hidden_outputs.dot(self.weights_hidden_to_output.T) - self.bias_hidden_to_output
            final_output_vector = self.output_activation_function(np.array([final_inputs]))[0]
            # ##END Forward pass ###
            ##############################################################################

            # ##############################################################
            # ### Backward pass --- calculate grad ###
            g_vector = targets_list[k] * (1 - final_output_vector) - final_output_vector * (1 - targets_list[k])

            hidden_to_output_grad += self.lr * (hidden_outputs * g_vector.reshape(-1, 1))
            bias_hidden_to_output_grad += self.lr * g_vector

            e_vector = 1 / np.square(np.cosh(hidden_inputs)) * (
            (self.weights_hidden_to_output * g_vector.reshape(-1, 1)).sum(0))  # Vector e_vector

            input_to_hidden_grad += self.lr * (e_vector.reshape(-1, 1) * inputs_matrix[k])
            bias_input_to_hidden_grad += self.lr * e_vector
            # ### END calculate grad ###
            #################################################################

        # Update the weights
        self.weights_hidden_to_output += hidden_to_output_grad / batch_size
        self.weights_input_to_hidden += input_to_hidden_grad / batch_size
        self.bias_input_to_hidden -= bias_input_to_hidden_grad / batch_size
        self.bias_hidden_to_output -= bias_hidden_to_output_grad / batch_size

        ##################################################################
        # 本轮更新结束，计算更新后的损失函数值
        if rounds % OUTPUT_CYCLE == 0:
            print("--------------------")
            print("训练集---")
            acc, entropy = self.calculate_lose(inputs_matrix, targets_list)
            if acc > self.best_acc:
                print("最高准确率更新为", acc)
                self.best_acc = acc
                self.best_bias_hidden_to_output = self.bias_hidden_to_output
                self.best_bias_input_to_hidden = self.bias_input_to_hidden
                self.best_weights_hidden_to_output = self.best_weights_hidden_to_output
                self.best_weights_input_to_hidden = self.best_bias_input_to_hidden
            self.accuracy_list.append(acc)
            self.entropy_list.append(entropy)
            print("\n验证集---")
            vali_acc, vali_entropy = self.calculate_lose(vali_inputs_matrix, vali_targets_list)
            self.vali_accuracy_list.append(vali_acc)
            self.vali_entropy_list.append(vali_entropy)
            print("--------------------\n")


    def calculate_lose(self, inputs_matrix, targets_list):
        final_outputs = self.train_run(inputs_matrix)
        diff = final_outputs - targets_list
        diff_max = diff.max(1)
        cnt_right = np.count_nonzero(diff_max == 0)
        accuracy = cnt_right / len(targets_list)
        print("准确率", accuracy)
        # self.accuracy_list.append(accuracy)

        final_outputs = self.raw_run(inputs_matrix)
        log_one = targets_list * np.log(final_outputs) + (1 - targets_list) * np.log(1 - final_outputs)
        log_k = -np.sum(log_one, axis=1)
        total_entropy = np.mean(log_k)
        print("交叉熵", total_entropy)
        return accuracy, total_entropy

    def raw_run(self, inputs_matrix):
        hidden_inputs, hidden_outputs, final_inputs, final_outputs = self.train_forward_pass(inputs_matrix)
        return final_outputs

    def train_run(self, inputs_matrix):
        hidden_inputs, hidden_outputs, final_inputs, final_outputs = self.train_forward_pass(inputs_matrix)
        if PRINT_NODE:
            print("final:")
            print(final_outputs)
            print("hidden_outputs:")
            print(hidden_outputs)
        print("当前最高正确率", self.best_acc)
        np.apply_along_axis(p_to_10, 1, final_outputs)
        return final_outputs

    def train_forward_pass(self, inputs_matrix):
        hidden_inputs = inputs_matrix.dot(self.weights_input_to_hidden.T) - self.bias_input_to_hidden
        # matrix, each line is a hidden output vector
        hidden_outputs = self.hidden_activation_function(hidden_inputs)

        # Output layer (which is a VECTOR, each element is yk_hat)
        final_inputs = hidden_outputs.dot(self.weights_hidden_to_output.T) - self.bias_hidden_to_output
        final_outputs = self.output_activation_function(final_inputs)
        return hidden_inputs, hidden_outputs, final_inputs, final_outputs

    def predict_run(self, inputs_matrix):
        hidden_inputs, hidden_outputs, final_inputs, final_outputs = self.predict_forward_pass(inputs_matrix)
        print("final:")
        print(final_outputs)
        print("hidden_outputs:")
        print(hidden_outputs)
        np.apply_along_axis(p_to_10, 1, final_outputs)
        return final_outputs

    def predict_forward_pass(self, inputs_matrix):
        hidden_inputs = inputs_matrix.dot(self.best_weights_input_to_hidden.T) - self.best_bias_input_to_hidden
        # matrix, each line is a hidden output vector
        hidden_outputs = self.hidden_activation_function(hidden_inputs)

        # Output layer (which is a VECTOR, each element is yk_hat)
        final_inputs = hidden_outputs.dot(self.best_weights_hidden_to_output.T) - self.best_bias_hidden_to_output
        final_outputs = self.output_activation_function(final_inputs)
        return hidden_inputs, hidden_outputs, final_inputs, final_outputs

    def dropout(self, x, prob):
        if prob < 0. or prob >= 1:  # prob，必须在0~1之间
            raise Exception('Dropout level must be in interval [0, 1[.')
        retain_prob = 1. - prob
        # 我们通过binomial函数，生成与x一样的维数向量。binomial函数就像抛硬币一样，我们可以把每个神经元当做抛硬币一样
        # 硬币 正面的概率为p，n表示每个神经元试验的次数
        # 因为我们每个神经元只需要抛一次就可以了所以n=1，size参数是我们有多少个硬币。
        sample = np.random.binomial(n=1, p=retain_prob, size=x.shape)  # 生成一个0、1分布的向量
        x *= sample  # 0、1与x相乘，我们就可以屏蔽某些神经元，让它们的值变为0
        x /= retain_prob
        return x

    def mask_x(self, x, prob, mask):

        retain_prob = 1. - prob
        x *= mask  # 0、1与x相乘，我们就可以屏蔽某些神经元，让它们的值变为0
        x /= retain_prob
        return x

    def dropout_mask(self, mask_size, prob):
        if prob < 0. or prob >= 1:  # prob，0~1之间
            raise Exception('Dropout level must be in interval [0, 1[.')
        retain_prob = 1. - prob
        mask = np.random.binomial(n=1, p=retain_prob, size=mask_size)  # 生成一个0、1分布的向量
        return mask


def to_label(x):
    if x.argmax() == 0:
        return 'LOW'
    if x.argmax() == 1:
        return 'MID'
    if x.argmax() == 2:
        return 'HIG'


# ########################## MAIN #####################################
PRE_PROCESS_FUCTION = de_center_no_abs
OUTPUT_CYCLE = 100
VERSION = "drop=0.0，固定batchsize，固定步长"
PRINT_NODE = False

# ### Load data and train ###
print(VERSION)
multiple_read_data.read_train_text()
multiple_read_data.xLines_train = PRE_PROCESS_FUCTION(multiple_read_data.xLines_train)
print(multiple_read_data.xLines_train[0])
nn = NeuralNetwork(len(multiple_read_data.xLines_train[0]), 300, 3, 2, dropout_prob=0.0)
multiple_read_data.read_vali_text()
multiple_read_data.xLines_vali = PRE_PROCESS_FUCTION(multiple_read_data.xLines_vali)

print("训练", multiple_read_data.y_train[0:3])
print("验证", multiple_read_data.y_vali[0:3])
for i in range(2000):
    nn.train(multiple_read_data.xLines_train, multiple_read_data.y_train,
             multiple_read_data.xLines_vali, multiple_read_data.y_vali,
             1000, i)  # min(round(i / 2) + 1, 1000)

print(VERSION)
print("训练集")
print("正确率", nn.accuracy_list)
print("交叉熵", nn.entropy_list)
print("验证集")
print("正确率", nn.vali_accuracy_list)
print("交叉熵", nn.vali_entropy_list)
multiple_read_data.read_test_text()
multiple_read_data.xLines_test = PRE_PROCESS_FUCTION(multiple_read_data.xLines_test)
predicts = nn.train_run(multiple_read_data.xLines_test)
predicts = np.apply_along_axis(to_label, 1, predicts)

t = time.time()
strt = str(t)
print(strt)

outfile = "F://AI//Project//multi-classification//y_predict_test_" + strt + ".csv"
with open(outfile, 'w') as fot:
    for r in list(predicts):
        fot.write(r + "\n")
